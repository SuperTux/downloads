/*
 *  touch_circle.cpp
 *  SuperTux
 *
 *  Created by Tobias Hassenkloever on 31.07.11.
 *  Copyright 2011 Tobias Hassenkloever. All rights reserved.
 *
 */

#include "globals.h"
#include "texture.h"
#include "touch_circle.h"

TouchCircle::TouchCircle(char *pathToImage, int posX, int posY, int posX_r, int posY_r)
{
	x = posX;
	y = posY;
	x_right = posX_r;
	y_right = posY_r;
	
	// load actual sprites
	sprite = new Surface(pathToImage, USE_ALPHA);
}

TouchCircle::~TouchCircle()
{
	// release sprites
	delete sprite;
}

bool TouchCircle::inBounds(int posX, int posY)
{
	int leftXCorner, rightXCorner, upYCorner, downYCorner;

	if (right_hander){
		
		leftXCorner = x_right;
		rightXCorner = x_right + CIRCLE_WIDTH;
		upYCorner = y_right;
		downYCorner = y_right + CIRCLE_WIDTH;
	} else {
		leftXCorner = x;
		rightXCorner = x + CIRCLE_WIDTH;
		upYCorner = y;
		downYCorner = y + CIRCLE_WIDTH;
	}

	
	if (posX >= leftXCorner && posX <= rightXCorner && posY >= upYCorner && posY <= downYCorner)
	{
		return true;
	} else {
		return false;
	}
}


CircleSector TouchCircle::getSector(int posX, int posY)
{
	CircleSector result = CircleSector_None;
	int temp_x, temp_y;
	
	if (right_hander) {
		temp_x = x_right;
		temp_y = y_right;
	} else { 
		temp_x = x;
		temp_y = y;
	}
	
	// calculate the relative position in the circle 0 - 1.0
	int x_zero = posX - temp_x;
	int y_zero = posY - temp_y;
	float x_norm = (float) x_zero / (float) (CIRCLE_WIDTH);
	float y_norm = (float) y_zero / (float) (CIRCLE_WIDTH);
	
#ifdef DEBUG
	printf("x_zero: %d   y_zero  %d\n", x_zero, y_zero);
	printf("x_norm: %f   y_norm  %f\n", x_norm, y_norm);
#endif
	
	if (x_norm < 0.20 && y_norm < 0.20) {
		
		result = CircleSector_LeftLeftUpUp;
	} else if (x_norm < 0.20 && y_norm < 0.35) {
		
		result = CircleSector_LeftLeftUp;
	} else if (x_norm < 0.20 && y_norm < 0.65) {
		
		result = CircleSector_LeftLeft;
	} else if (x_norm < 0.20 && y_norm < 0.8) {
		
		result = CircleSector_LeftLeftDown;
	} else if (x_norm < 0.20 && y_norm < 1.0) {
		
		result = CircleSector_LeftLeftDownDown;
	}
	
	else if (x_norm < 0.35 && y_norm < 0.20) {
		
		result = CircleSector_LeftUpUp;
	} else if (x_norm < 0.35 && y_norm < 0.35) {
		
		result = CircleSector_LeftUp;
	} else if (x_norm < 0.35 && y_norm < 0.65) {
		
		result = CircleSector_Left;
	} else if (x_norm < 0.35 && y_norm < 0.8) {
		
		result = CircleSector_LeftDown;
	} else if (x_norm < 0.35 && y_norm < 1.0) {
		
		result = CircleSector_LeftDownDown;
	}
	
	else if (x_norm < 0.65 && y_norm < 0.20) {
		
		result = CircleSector_UpUp;
	} else if (x_norm < 0.65 && y_norm < 0.35) {
		
		result = CircleSector_Up;
	} else if (x_norm < 0.65 && y_norm < 0.65) {
		
		result = CircleSector_Center;
	} else if (x_norm < 0.65 && y_norm < 0.8) {
		
		result = CircleSector_Down;
	} else if (x_norm < 0.65 && y_norm < 1.0) {
		
		result = CircleSector_DownDown;
	}
	
	else if (x_norm < 0.80 && y_norm < 0.20) {
		
		result = CircleSector_RightUpUp;
	} else if (x_norm < 0.80 && y_norm < 0.35) {
		
		result = CircleSector_RightUp;
	} else if (x_norm < 0.80 && y_norm < 0.65) {
		
		result = CircleSector_Right;
	} else if (x_norm < 0.80 && y_norm < 0.8) {
		
		result = CircleSector_RightDown;
	} else if (x_norm < 0.80 && y_norm < 1.0) {
		
		result = CircleSector_RightDownDown;
	}
	
	else if (x_norm < 1.0 && y_norm < 0.20) {
		
		result = CircleSector_RightRightUpUp;
	} else if (x_norm < 1.0 && y_norm < 0.35) {
		
		result = CircleSector_RightRightUp;
	} else if (x_norm < 1.0 && y_norm < 0.65) {
		
		result = CircleSector_RightRight;
	} else if (x_norm < 1.0 && y_norm < 0.8) {
		
		result = CircleSector_RightRightDown;
	} else if (x_norm < 1.0 && y_norm < 1.0) {
		
		result = CircleSector_RightRightDownDown;
	}
	 	
	return result;
}

void TouchCircle::draw()
{
	if (right_hander) {
		sprite->draw(x_right, y_right); 
	} else { 
		sprite->draw(x, y);
	}
}

/*
 *  touch_button.h
 *  SuperTux
 *
 *  Created by Tobias Hassenkloever on 28.07.11.
 *  Copyright 2011 Tobias Hassenkloever. All rights reserved.
 *
 */


#ifndef TOUCHBUTTON_H
#define TOUCHBUTTON_H

#define BUTTON_WIDTH 32
#define BOUND_WIDTH 16

/**
 Touch_Button Class
 */
class TouchButton
{
public:
	TouchButton(char *pathToImage, char *pathToImagePressed, int posX, int posY, bool big);
	TouchButton(char *pathToImage, char *pathToImagePressed, int posX, int posY, int posX_r, int posY_r, bool big);
	~TouchButton();
	
	bool inBounds(int posX, int posY);
	void draw();
	
	void setPressed(bool isPressed) { pressed = isPressed; };
	
private:
	bool pressed;
	int x;
	int y;
	int x_r;
	int y_r;
	bool bigButton;
	 
	Surface* sprite;
	Surface* sprite_pressed;
};


#endif
/*
 *  touch_button.cpp
 *  SuperTux
 *
 *  Created by Tobias Hassenkloever on 28.07.11.
 *  Copyright 2011 Tobias Hassenkloever. All rights reserved.
 *
 */

#include "globals.h"
#include "texture.h"
#include "touch_button.h"

TouchButton::TouchButton(char *pathToImage, char *pathToImagePressed, int posX, int posY, bool big = false)
{
	x = posX;
	y = posY;
	x_r = posX;
	y_r = posY;
	pressed = false;
	bigButton = big;
	
	// load actual sprites
	sprite = new Surface(pathToImage, USE_ALPHA);
	sprite_pressed = new Surface(pathToImagePressed, USE_ALPHA);
}


TouchButton::TouchButton(char *pathToImage, char *pathToImagePressed, int posX, int posY, int posX_r, int posY_r, bool big)
{
	x = posX;
	y = posY;
	x_r = posX_r;
	y_r = posY_r;
	pressed = false;
	bigButton = big;
	
	// load actual sprites
	sprite = new Surface(pathToImage, USE_ALPHA);
	sprite_pressed = new Surface(pathToImagePressed, USE_ALPHA);
}

TouchButton::~TouchButton()
{
	// release sprites
	delete sprite;
	delete sprite_pressed;
}

bool TouchButton::inBounds(int posX, int posY)
{
	int leftXCorner, rightXCorner, upYCorner, downYCorner, temp_x, temp_y;
	
	if (right_hander) {
		
		temp_x = x_r;
		temp_y = y_r; 
	} else {
		temp_x = x;
		temp_y = y;		
	}

	if (bigButton) 
	{
		leftXCorner = temp_x;
		rightXCorner = temp_x + (2 * BUTTON_WIDTH);
		upYCorner = temp_y;
		downYCorner = temp_y + (2 *BUTTON_WIDTH);
	} else {
		
		leftXCorner = temp_x - BOUND_WIDTH;
		rightXCorner = temp_x + BUTTON_WIDTH + BOUND_WIDTH;
		upYCorner = temp_y - BOUND_WIDTH;
		downYCorner = temp_y + BUTTON_WIDTH + BOUND_WIDTH;
	}
	
	
	if (posX >= leftXCorner && posX <= rightXCorner && posY >= upYCorner && posY <= downYCorner)
	{
		return true;
	} else {
		return false;
	}
	
}

void TouchButton::draw()
{
	int temp_x, temp_y;
	
	if (right_hander) {
		
		temp_x = x_r;
		temp_y = y_r; 
	} else {
		temp_x = x;
		temp_y = y;		
	}
	
	if (pressed) {
		sprite_pressed->draw(temp_x, temp_y);
	} else {
		sprite->draw(temp_x, temp_y);
	}
	
}

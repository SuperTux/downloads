/*
 *  touch_circle.h
 *  SuperTux
 *
 *  Created by Tobias Hassenkloever on 31.07.11.
 *  Copyright 2011 Tobias Hassenkloever. All rights reserved.
 *
 */

#ifndef TOUCHCIRCLE_H
#define TOUCHCIRCLE_H

#include "globals.h"
#include "texture.h"

#define CIRCLE_WIDTH 192
#define CIRCLE_BOUND_WIDTH 0

enum CircleSector {
	CircleSector_LeftLeftUpUp,
	CircleSector_LeftLeftUp,
	CircleSector_LeftUpUp,
	CircleSector_LeftUp,
	CircleSector_LeftLeft,
	CircleSector_Left,
	CircleSector_UpUp,
	CircleSector_Up,
	CircleSector_RightRightUpUp,
	CircleSector_RightRightUp,
	CircleSector_RightUpUp,
	CircleSector_RightUp,
	CircleSector_RightRight,
	CircleSector_Right,
	CircleSector_LeftLeftDownDown,
	CircleSector_LeftLeftDown,
	CircleSector_LeftDownDown,
	CircleSector_LeftDown,
	CircleSector_DownDown,
	CircleSector_Down,
	CircleSector_RightRightDownDown,
	CircleSector_RightRightDown,
	CircleSector_RightDownDown,
	CircleSector_RightDown,
	CircleSector_Center,
	CircleSector_None
};

/**
 Touch_Circle Class
 */
class TouchCircle
{
public:
	TouchCircle(char *pathToImage, int posX, int posY, int posX_r, int posY_r);
	~TouchCircle();
	
	bool inBounds(int posX, int posY);
	
	CircleSector getSector(int posX, int posY);
	
	void draw();
	
private:
	int x;
	int y;
	
	int x_right;
	int y_right;
	
	Surface* sprite;
};


#endif
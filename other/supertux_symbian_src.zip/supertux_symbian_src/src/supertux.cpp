//  $Id: supertux.cpp 997 2004-05-05 16:07:20Z rmcruz $
// 
//  SuperTux
//  Copyright (C) 2004 Tobias Glaesser <tobi.web@gmx.de>
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
//  02111-1307, USA.

#include <sys/types.h>
#include <ctype.h>

#include "defines.h"
#include "globals.h"
#include "setup.h"
#include "intro.h"
#include "title.h"
#include "gameloop.h"
#include "leveleditor.h"
#include "screen.h"
#include "worldmap.h"
#include "resources.h"
#include "texture.h"
#include "tile.h"
FILE* mystdout;
FILE* mystderr;
int main(int argc, char * argv[])
{
#ifdef UIQ3
	mystdout = fopen("c:\\shared\\supertux\\stdout.txt","wb");
	mystderr = fopen("c:\\shared\\supertux\\stderr.txt","wb");
#else
	mystdout = fopen("c:\\data\\supertux\\stdout.txt","wb");
	mystderr = fopen("c:\\data\\supertux\\stderr.txt","wb");
#endif
	*stdout = *mystdout;
	*stderr = *mystderr;
  st_directory_setup();
  parseargs(argc, argv);
  
  st_audio_setup();
  st_video_setup();
  st_joystick_setup();
  st_general_setup();
  st_menu();
  loadshared();
#if !defined GP2X && !defined __SYMBIAN32__
  if (launch_leveleditor_mode && level_startup_file)
    {
    leveleditor(level_startup_file);
  } else 
#endif
  if (level_startup_file)
    {
      GameSession session(level_startup_file, 1, ST_GL_LOAD_LEVEL_FILE);
      session.run();
    }
  else
    {  
      title();
    }
  
  clearscreen(0, 0, 0);
  updatescreen();

  unloadshared();
  st_general_free();
  TileManager::destroy_instance();
#ifdef DEBUG
  Surface::debug_check();
#endif
  st_shutdown();
  
  return 0;
}

#ifdef __SYMBIAN32__
#include <e32std.h>
#include <e32def.h>
#include <e32svr.h>
#include <e32base.h>
#include <eikapp.h>
#include <sdlapp.h>

char KResourceDir[256];

class CSuperTuxApp : public CSDLApp {
public:
	CSuperTuxApp();
	~CSuperTuxApp();
	/**
	 * This has a default empty implementation.
	 * Is called just before SDL_Main is called to allow init of system vars
	 */
	virtual	void PreInitializeAppL()
		{
		strcpy(KResourceDir, "x:\\resource\\apps");		
		KResourceDir[0] = BitmapStoreName()[0];
		setenv("HOME", KResourceDir, 1);
		strcat(KResourceDir, "\\supertux");
		}
#if defined (UIQ3)
	/**
	 * Returns the resource id to be used to declare the views supported by this UIQ3 app
	 * @return TInt, resource id
	 */
	TInt ViewResourceId();
#endif
	TUid AppDllUid() const;
};

// this function is called automatically by the SymbianOS to deliver the new CApaApplication object
#if !defined (UIQ3) && !defined (S60V3)
EXPORT_C 
#endif
CApaApplication* NewApplication() {
	// Return pointer to newly created CQMApp
	return new CSuperTuxApp;
}

#if defined (UIQ3) || defined (S60V3)
#include <eikstart.h>
// E32Main() contains the program's start up code, the entry point for an EXE.
GLDEF_C TInt E32Main() {
 	return EikStart::RunApplication(NewApplication);
}
#endif

#ifdef UIQ3
#include <SuperTux.rsg>
/**
	 * Returns the resource id to be used to declare the views supported by this UIQ3 app
	 * @return TInt, resource id
	 */
TInt CSuperTuxApp::ViewResourceId()
{
	return R_SDL_VIEW_UI_CONFIGURATIONS;
}
#endif

CSuperTuxApp::CSuperTuxApp() {
}

CSuperTuxApp::~CSuperTuxApp() {
}

TUid CSuperTuxApp::AppDllUid() const
{
	return  TUid::Uid(0xA000A003);
}
#endif
